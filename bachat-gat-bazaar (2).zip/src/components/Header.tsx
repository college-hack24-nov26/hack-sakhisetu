import React from 'react';
import { ShoppingBag, Languages } from 'lucide-react';
import { Language } from '../types';

interface HeaderProps {
  activeTab: 'shop' | 'register' | 'studio' | 'ledger';
  setActiveTab: (tab: 'shop' | 'register' | 'studio' | 'ledger') => void;
  lang: Language;
  onToggleLang: () => void;
  cartCount: number;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  onToggleLang,
  cartCount,
  onOpenCart,
}) => {
  const isMarathi = lang === 'mr';

  const navItems: { id: 'shop' | 'register' | 'studio' | 'ledger'; mr: string; en: string }[] = [
    { id: 'shop', mr: 'दुकान (खरेदी)', en: 'Shop' },
    { id: 'register', mr: 'व्हॉइस नोंदणी', en: 'Voice Register' },
    { id: 'studio', mr: 'AI स्टुडिओ', en: 'AI Studio' },
    { id: 'ledger', mr: 'नोंदवही (हिशोब)', en: 'Ledger' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <button
          type="button"
          onClick={() => setActiveTab('shop')}
          className="text-left whitespace-nowrap shrink-0 focus:outline-none"
        >
          <span className="text-xl sm:text-2xl font-black tracking-tight text-[#80141c] hover:opacity-90 block">
            बचत गट बाजार
          </span>
          <span className="text-[10px] text-stone-500 font-semibold tracking-wider block -mt-1">
            Bachat Gat Bazaar
          </span>
        </button>

        {/* Zone 2: Single-Line Nav Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-bold text-stone-700">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors relative ${
                activeTab === item.id
                  ? 'text-[#80141c] font-black'
                  : 'hover:text-stone-950 text-stone-600'
              }`}
            >
              {isMarathi ? item.mr : item.en}
              {activeTab === item.id && (
                <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#80141c] rounded-full" />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Language Toggle & Cart Button */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Marathi / English One-Tap Toggle */}
          <button
            type="button"
            onClick={onToggleLang}
            className="touch-target inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border-2 border-stone-300 hover:border-stone-500 bg-stone-50 text-xs sm:text-sm font-black text-stone-800 transition-colors"
            title="Toggle Language / भाषा बदला"
          >
            <Languages className="w-4 h-4 text-[#80141c]" />
            <span>{isMarathi ? 'English' : 'मराठी'}</span>
          </button>

          {/* Cart Bag Button */}
          <button
            type="button"
            onClick={onOpenCart}
            className="touch-target relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#80141c] hover:bg-[#5d0c12] text-white text-xs sm:text-sm font-bold shadow-md transition-transform active:scale-95"
            aria-label="Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">{isMarathi ? 'पिशवी' : 'Bag'}</span>
            {cartCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-400 text-stone-900 text-xs font-black flex items-center justify-center font-mono">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Strip */}
      <div className="md:hidden flex items-center justify-around border-t border-stone-200 bg-stone-50 px-2 py-1.5">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveTab(item.id)}
            className={`text-xs py-2 px-2.5 rounded-lg font-bold whitespace-nowrap transition-colors ${
              activeTab === item.id
                ? 'bg-[#80141c] text-white'
                : 'text-stone-700 hover:bg-stone-200'
            }`}
          >
            {isMarathi ? item.mr.split(' ')[0] : item.en}
          </button>
        ))}
      </div>
    </header>
  );
};
