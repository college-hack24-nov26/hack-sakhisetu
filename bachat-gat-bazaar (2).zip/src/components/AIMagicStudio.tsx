import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Sliders, Upload, CheckCircle2, RotateCcw, ShieldCheck, Sun, Eye } from 'lucide-react';
import { Language, Product } from '../types';
import { VoiceHelpButton } from './VoiceHelpButton';
import { enhanceSHGProductPhoto, DEFAULT_ENHANCEMENT, EnhancementSettings } from '../lib/imageOptimizer';

interface AIMagicStudioProps {
  products: Product[];
  onUseEnhancedPhoto?: (photoUrl: string) => void;
  lang: Language;
}

export const AIMagicStudio: React.FC<AIMagicStudioProps> = ({ products, onUseEnhancedPhoto, lang }) => {
  const isMarathi = lang === 'mr';

  const [selectedProduct, setSelectedProduct] = useState<Product>(products[0]);
  const [settings, setSettings] = useState<EnhancementSettings>({ ...DEFAULT_ENHANCEMENT });
  const [enhancedDataUrl, setEnhancedDataUrl] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showSideBySide, setShowSideBySide] = useState<boolean>(true);
  const [splitPosition, setSplitPosition] = useState<number>(50); // percentage

  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    runEnhancement();
  }, [selectedProduct, settings]);

  const runEnhancement = async () => {
    setIsProcessing(true);
    try {
      const result = await enhanceSHGProductPhoto(selectedProduct.imageUrl, settings);
      setEnhancedDataUrl(result);
    } catch (e) {
      console.warn('Enhancement error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCustomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        if (url) {
          const customProd: Product = {
            ...selectedProduct,
            id: `custom-${Date.now()}`,
            nameMr: 'स्वतःचा फोटो',
            nameEn: 'My Uploaded Photo',
            imageUrl: url,
          };
          setSelectedProduct(customProd);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    setSettings({ ...DEFAULT_ENHANCEMENT });
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Top Banner & Audio Guide */}
      <div className="bg-white border-2 border-stone-300 rounded-3xl p-6 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-amber-100 text-amber-900">
                <Sparkles className="w-6 h-6 text-amber-700" />
              </span>
              <h1 className="text-2xl md:text-3xl font-black text-stone-900">
                {isMarathi ? 'AI मॅजिक स्टुडिओ (छायाचित्र सुधारक)' : 'AI Magic Studio (Photo Enhancer)'}
              </h1>
            </div>
            <p className="text-sm font-semibold text-stone-600 mt-1">
              {isMarathi
                ? 'ग्रामीण प्रकाशातील फोटोची स्पष्टता वाढवा - मूळ माल न बदलता'
                : 'Enhance low-light rural smartphone photos without altering genuine product'}
            </p>
          </div>
          <VoiceHelpButton
            lang={lang}
            textToSpeak={
              isMarathi
                ? 'हे AI मॅजिक स्टुडिओ आहे. साध्या मोबाईल कॅमेऱ्याने काढलेल्या फोटोमधील सावल्या कमी करून प्रकाश आणि स्पष्टता वाढवण्यासाठी याचा वापर करा. येथे मालाचा मूळ आकार किंवा लेबल बदलले जात नाही.'
                : 'This is AI Magic Studio. Enhance smartphone photos taken in dim rural light with auto shadow-lifting and sharpness without altering real labels.'
            }
          />
        </div>

        {/* Ethical Transparency Box */}
        <div className="mt-4 p-4 bg-emerald-50 border-2 border-emerald-600 rounded-2xl flex items-start gap-3">
          <ShieldCheck className="w-6 h-6 text-emerald-800 shrink-0 mt-0.5" />
          <div className="text-xs text-emerald-950 space-y-1">
            <span className="font-bold text-sm block">
              {isMarathi
                ? 'प्रामाणिक छायाचित्र धोरण (Ethical Rural Photography):'
                : 'Ethical Photography Policy:'}
            </span>
            <p className="leading-relaxed font-medium">
              {isMarathi
                ? 'हा स्टुडिओ केवळ अंधुक घरातील सावल्या (Shadows) आणि कॅमेरा लेन्सवरील धूसरपणा दूर करतो. मूळ मालाचा आकार, रंग, लेबल किंवा पॅकेजिंगमध्ये कसलाही खोटा बदल (AI Hallucination) केला जात नाही.'
                : 'This tool lifts harsh smartphone shadows and boosts label edge clarity. It strictly preserves the genuine product shape, colors, and physical packaging without synthetic generative alterations.'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Studio Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Interactive Comparison Canvas */}
        <div className="lg:col-span-7 bg-white border-2 border-stone-300 rounded-3xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between text-xs font-bold text-stone-600">
            <span className="flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-stone-700" />
              {isMarathi ? 'थेट तुलना (Before / After)' : 'Live Comparison (Before / After)'}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowSideBySide(!showSideBySide)}
                className="px-3 py-1 rounded-lg border border-stone-300 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold"
              >
                {showSideBySide
                  ? isMarathi ? 'स्लायडर दृश्य' : 'Slider View'
                  : isMarathi ? 'शेजारी-शेजारी' : 'Side-by-Side'}
              </button>
            </div>
          </div>

          {/* Photo Display Container */}
          <div
            ref={containerRef}
            className="relative w-full aspect-4/3 bg-stone-100 rounded-2xl overflow-hidden border-2 border-stone-400 select-none shadow-inner"
          >
            {showSideBySide ? (
              <div className="grid grid-cols-2 h-full w-full">
                {/* Left: Original */}
                <div className="relative h-full border-r border-stone-300 bg-stone-200 flex flex-col">
                  <img
                    src={selectedProduct.imageUrl}
                    alt="Original"
                    className="w-full h-full object-contain filter contrast-90 brightness-95"
                  />
                  <div className="absolute top-3 left-3 bg-stone-900/80 text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                    {isMarathi ? 'आधी (सावली असलेला)' : 'Before (Dim Shadow)'}
                  </div>
                </div>

                {/* Right: Enhanced */}
                <div className="relative h-full bg-white flex flex-col">
                  <img
                    src={enhancedDataUrl || selectedProduct.imageUrl}
                    alt="Enhanced"
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-3 right-3 bg-emerald-800 text-white text-[11px] font-bold px-2.5 py-1 rounded-md shadow-sm">
                    {isMarathi ? 'सुधारित (स्पष्ट लेबल)' : 'Enhanced (Crisp)'}
                  </div>
                </div>
              </div>
            ) : (
              /* Interactive Split Slider */
              <div className="relative w-full h-full">
                <img
                  src={selectedProduct.imageUrl}
                  alt="Original"
                  className="absolute inset-0 w-full h-full object-contain filter contrast-90 brightness-90"
                />
                <div
                  className="absolute inset-y-0 left-0 overflow-hidden"
                  style={{ width: `${splitPosition}%` }}
                >
                  <img
                    src={enhancedDataUrl || selectedProduct.imageUrl}
                    alt="Enhanced"
                    className="absolute inset-0 w-full h-full object-contain"
                    style={{ width: '100%', maxWidth: 'none' }}
                  />
                </div>
                {/* Divider Line */}
                <div
                  className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize flex items-center justify-center shadow-lg"
                  style={{ left: `${splitPosition}%` }}
                >
                  <div className="w-8 h-8 rounded-full bg-amber-500 border-2 border-white text-stone-900 flex items-center justify-center text-xs font-black shadow-md">
                    ⇔
                  </div>
                </div>
                {/* Range Controller */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={splitPosition}
                  onChange={(e) => setSplitPosition(Number(e.target.value))}
                  className="absolute inset-x-0 bottom-3 mx-auto w-3/4 opacity-80"
                />
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <label className="touch-target cursor-pointer inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 border-stone-400 bg-stone-100 hover:bg-stone-200 font-bold text-stone-800 text-sm">
              <Upload className="w-5 h-5 text-stone-700" />
              <span>{isMarathi ? 'स्वतःचा फोटो अपलोड करा' : 'Upload SHG Photo'}</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleCustomUpload}
                className="hidden"
              />
            </label>

            {onUseEnhancedPhoto && (
              <button
                type="button"
                onClick={() => onUseEnhancedPhoto(enhancedDataUrl || selectedProduct.imageUrl)}
                className="touch-target inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#14532d] hover:bg-[#166534] font-black text-white text-sm shadow-md"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>{isMarathi ? 'हा फोटो मालासाठी वापरा' : 'Use for Product'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Column: Controls & Presets */}
        <div className="lg:col-span-5 space-y-5">
          {/* Preset Selector */}
          <div className="bg-white border-2 border-stone-300 rounded-3xl p-5 shadow-md">
            <h3 className="text-base font-black text-stone-900 mb-3 flex items-center gap-2">
              <Sun className="w-5 h-5 text-amber-600" />
              <span>{isMarathi ? 'मालाचा नमुना निवडा:' : 'Select Sample Product:'}</span>
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {products.slice(0, 6).map((prod) => (
                <button
                  key={prod.id}
                  type="button"
                  onClick={() => setSelectedProduct(prod)}
                  className={`p-2 rounded-xl border-2 text-left transition-all ${
                    selectedProduct.id === prod.id
                      ? 'border-[#80141c] bg-red-50 text-[#80141c] font-black shadow-sm'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700 font-semibold'
                  }`}
                >
                  <div className="w-full aspect-square rounded-lg bg-stone-100 mb-1 overflow-hidden">
                    <img src={prod.imageUrl} alt={prod.nameMr} className="w-full h-full object-cover" />
                  </div>
                  <span className="text-[11px] block truncate leading-tight">
                    {isMarathi ? prod.nameMr : prod.nameEn}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Adjustment Sliders */}
          <div className="bg-white border-2 border-stone-300 rounded-3xl p-5 shadow-md space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200">
              <h3 className="text-base font-black text-stone-900 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-stone-700" />
                <span>{isMarathi ? 'छायाचित्र नियंत्रणे' : 'Adjustment Controls'}</span>
              </h3>
              <button
                type="button"
                onClick={handleReset}
                className="text-xs font-bold text-stone-500 hover:text-stone-900 flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isMarathi ? 'मूळ स्थितीत' : 'Reset'}</span>
              </button>
            </div>

            {/* Slider 1: Shadow Lift */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-stone-700">
                <span>{isMarathi ? 'सावल्या कमी करा (Shadow Lift)' : 'Lift Dark Shadows'}</span>
                <span className="font-mono text-amber-900">+{settings.shadowLift}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={settings.shadowLift}
                onChange={(e) => setSettings({ ...settings, shadowLift: Number(e.target.value) })}
                className="w-full accent-[#80141c]"
              />
              <span className="text-[10px] text-stone-500 block">
                {isMarathi
                  ? 'अंधुक खोलीत काढलेल्या फोटोचे काळे डाग कमी करतो.'
                  : 'Illuminates dark packaging crevices without glare.'}
              </span>
            </div>

            {/* Slider 2: Brightness */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-stone-700">
                <span>{isMarathi ? 'उजेड / प्रकाश (Brightness)' : 'Brightness'}</span>
                <span className="font-mono text-amber-900">{settings.brightness}%</span>
              </div>
              <input
                type="range"
                min="90"
                max="130"
                value={settings.brightness}
                onChange={(e) => setSettings({ ...settings, brightness: Number(e.target.value) })}
                className="w-full accent-[#80141c]"
              />
            </div>

            {/* Slider 3: Contrast & Clarity */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-stone-700">
                <span>{isMarathi ? 'स्पष्टता व कॉन्ट्रास्ट (Clarity)' : 'Contrast & Label Clarity'}</span>
                <span className="font-mono text-amber-900">{settings.contrast}%</span>
              </div>
              <input
                type="range"
                min="95"
                max="140"
                value={settings.contrast}
                onChange={(e) => setSettings({ ...settings, contrast: Number(e.target.value) })}
                className="w-full accent-[#80141c]"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
