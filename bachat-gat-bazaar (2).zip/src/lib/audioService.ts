/**
 * Audio Service for Web Speech API (Recognition + Synthesis)
 * Tailored for Marathi (mr-IN) with Hindi (hi-IN) fallback and clear rural pacing.
 */

export interface TTSOptions {
  text: string;
  lang?: string;
  rate?: number;
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: unknown) => void;
}

export class AudioService {
  private static synth: SpeechSynthesis | null =
    typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis : null;

  public static isSpeechRecognitionSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  public static isTTSSupported(): boolean {
    return !!this.synth;
  }

  /**
   * Speak aloud in Marathi (or fallback language)
   */
  public static speak({
    text,
    lang = 'mr-IN',
    rate = 0.88,
    pitch = 1.0,
    onStart,
    onEnd,
    onError,
  }: TTSOptions): void {
    if (!this.synth) {
      console.warn('SpeechSynthesis is not supported in this environment.');
      onEnd?.();
      return;
    }

    try {
      this.synth.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = rate; // Gentle pace for rural elder clarity
      utterance.pitch = pitch;

      // Locate Marathi voice or Hindi voice
      const voices = this.synth.getVoices();
      const preferredVoice =
        voices.find((v) => v.lang === lang || v.lang.replace('_', '-') === lang) ||
        voices.find((v) => v.lang.startsWith(lang.slice(0, 2))) ||
        voices.find((v) => v.lang.startsWith('hi')) ||
        null;

      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.onstart = () => onStart?.();
      utterance.onend = () => onEnd?.();
      utterance.onerror = (e) => {
        console.warn('SpeechSynthesis error:', e);
        onError?.(e);
      };

      this.synth.speak(utterance);
    } catch (err) {
      console.warn('Audio speak error:', err);
      onEnd?.();
    }
  }

  public static stopSpeaking(): void {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  /**
   * Initialize speech recognition instance with preferred lang
   */
  public static createRecognizer(lang: 'mr-IN' | 'hi-IN' = 'mr-IN'): any {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      throw new Error('BROWSER_UNSUPPORTED');
    }

    const recognizer = new SpeechRecognition();
    recognizer.lang = lang;
    recognizer.continuous = false;
    recognizer.interimResults = false;
    recognizer.maxAlternatives = 3;

    return recognizer;
  }
}
