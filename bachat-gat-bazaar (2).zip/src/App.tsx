/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ProductCatalog } from './components/ProductCatalog';
import { VoiceProductRegistration } from './components/VoiceProductRegistration';
import { AIMagicStudio } from './components/AIMagicStudio';
import { SHGLedger } from './components/SHGLedger';
import { CartDrawer } from './components/CartDrawer';
import { INITIAL_PRODUCTS } from './data/mockProducts';
import { Product, CartItem, Order, Language } from './types';
import { ShieldCheck, Heart, Sparkles, Mic, Store, Info } from 'lucide-react';
import mrMessages from './messages/mr.json';
import enMessages from './messages/en.json';

export default function App() {
  const [lang, setLang] = useState<Language>('mr');
  const [activeTab, setActiveTab] = useState<'shop' | 'register' | 'studio' | 'ledger'>('shop');
  
  // Persisted or initial products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('shg_bazaar_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  // Cart items
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('shg_bazaar_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Placed orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('shg_bazaar_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  useEffect(() => {
    try {
      localStorage.setItem('shg_bazaar_products', JSON.stringify(products));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('shg_bazaar_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('shg_bazaar_orders', JSON.stringify(orders));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [orders]);

  const isMarathi = lang === 'mr';
  const messages = isMarathi ? mrMessages : enMessages;

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'mr' ? 'en' : 'mr'));
  };

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleProductSaved = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    setActiveTab('shop');
  };

  const handleOrderPlaced = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    // Clear cart after placement
    setCartItems([]);
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#faf7f2] text-stone-900 font-['Noto_Sans_Devanagari',sans-serif]">
      {/* Top Bar Contract (Wordmark - Links - Primary Action) */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        onToggleLang={handleToggleLang}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Hero Strip & Rural Trust Statement */}
      <section className="bg-gradient-to-b from-amber-100/60 to-transparent border-b border-stone-200 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-[#80141c]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#80141c]"></span>
              <span>{isMarathi ? 'महाराष्ट्र ग्रामीण महिला बचत गट उपक्रम' : 'Maharashtra Rural Women SHG Initiative'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-stone-900 tracking-tight leading-tight">
              {messages.tagline}
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 font-semibold max-w-2xl">
              {isMarathi
                ? 'कोणतेही इंग्रजी किंवा तांत्रिक अडथळे नाहीत. बोलून माल नोंदवा आणि ग्राहकांना थेट अस्सल घरगुती चव द्या.'
                : 'Zero language barriers. Voice-first product listing and direct doorstep delivery from certified rural Self-Help Groups.'}
            </p>
          </div>

          {/* Quick Action Badges */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className="touch-target inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#80141c] hover:bg-[#5d0c12] text-white font-black text-sm shadow-md active:scale-95 transition-transform"
            >
              <Mic className="w-5 h-5 text-amber-300" />
              <span>{isMarathi ? 'बोलून माल नोंदवा' : 'Voice Register'}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('studio')}
              className="touch-target inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-200 hover:bg-amber-300 border border-amber-500 text-stone-900 font-black text-sm shadow-sm active:scale-95 transition-transform"
            >
              <Sparkles className="w-4 h-4 text-amber-800" />
              <span>{isMarathi ? 'AI स्टुडिओ' : 'AI Studio'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 md:py-8">
        {activeTab === 'shop' && (
          <ProductCatalog
            products={products}
            onAddToCart={handleAddToCart}
            lang={lang}
          />
        )}

        {activeTab === 'register' && (
          <VoiceProductRegistration
            onProductSaved={handleProductSaved}
            lang={lang}
          />
        )}

        {activeTab === 'studio' && (
          <AIMagicStudio
            products={products}
            onUseEnhancedPhoto={() => {
              setActiveTab('register');
            }}
            lang={lang}
          />
        )}

        {activeTab === 'ledger' && (
          <SHGLedger
            products={products}
            orders={orders}
            lang={lang}
          />
        )}
      </main>

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onOrderPlaced={handleOrderPlaced}
        lang={lang}
      />

      {/* Footer strictly adhering to Anti-Slop principles: No fake engines or ornamental telemetry */}
      <footer className="mt-auto border-t-2 border-stone-200 bg-white py-6 px-4 text-xs text-stone-600">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="space-y-1">
            <span className="font-bold text-stone-900 text-sm block">
              बचत गट बाजार (Bachat Gat Bazaar)
            </span>
            <p className="text-[11px] text-stone-500">
              {isMarathi
                ? 'ग्रामीण महिला सक्षमीकरणासाठी मराठी-प्रथम, व्हॉइस-सक्षम तंत्रज्ञान.'
                : 'Marathi-first, voice-enabled technology empowering rural women self-help collectives.'}
            </p>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-semibold text-stone-600">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              {isMarathi ? '१००% अस्सल उत्पादने' : '100% Authentic Products'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{isMarathi ? 'थेट बचत गट' : 'Direct SHG Support'}</span>
            <span aria-hidden="true">·</span>
            <span>{isMarathi ? 'पारदर्शक हिशोब' : 'Transparent Accounting'}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
